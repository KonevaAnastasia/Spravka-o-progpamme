package main2;

//import Izfile21;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class Main2 implements ActionListener {

public Main2() {
initComponents();
}

private JFrame viewForm;

private void initComponents() {
viewForm = new JFrame("Программа Насти");
viewForm.setSize(400, 400);
viewForm.setVisible(true);
viewForm.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);

JButton but = new JButton("Начать работу");
but.setVisible(true);
but.setLocation(200, 120);
but.setSize(165, 50);

JButton button = new JButton("Подробнее");
button.setVisible(true);
button.setLocation(12, 120);
button.setSize(165, 50);
button.addActionListener(new ActionListener() {

//FileReader fr = new FileReader("D:/workspace/Test/1.txt");
//BufferedReader br = new BufferedReader(fr);
//LineNumberReader lr = new LineNumberReader(br);
//while ((s = lr.readLine()) != null) {
//sb.append(s);
//sb.append("\n");
//}

public void actionPerformed(ActionEvent e) {
// JOptionPane.showMessageDialog(viewForm, "Приветики",
// "Справка", JOptionPane.WARNING_MESSAGE);
// 
// }
//class Izfile {
//public static void main(String[] args) {
new Izfile21("Текст", 300, 400);

}

});
viewForm.getContentPane().add(button);
viewForm.getContentPane().add(new JLabel());
viewForm.getContentPane().add(but);
viewForm.getContentPane().add(new JLabel());
}

public void actionPerformed(ActionEvent action) {
}

public static void main(String[] args) {
SwingUtilities.invokeLater(new Runnable() {
public void run() {
new Main2();
}
});
}
}
